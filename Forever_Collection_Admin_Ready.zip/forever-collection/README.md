# Forever Collection — starter online shop

A colourful, mobile-friendly storefront for Forever Collection. The included shop UI has category filters, a product grid, a cart, and a checkout form. A Netlify Function is included for order email notifications and optional WhatsApp Cloud API template notifications.

## Important before taking real orders

This is a starter website, not a fully activated production store yet.

- The sample products, emojis, and prices are placeholders. Replace them with your actual product photos, names, prices, and stock.
- Customer login/accounts are not connected yet.
- COD order notification works only after the Netlify Function and email provider are configured.
- Online payment is NOT active. The checkout currently labels it as setup required. Add Razorpay checkout and server-side payment signature verification before accepting online payments.
- WhatsApp automation uses the official WhatsApp Business Cloud API. A personal WhatsApp number by itself cannot send automated API messages. You must set up a WhatsApp Business Platform number, opt-in, and an approved message template.
- Never put API keys, Gmail passwords, payment secrets, or WhatsApp tokens in frontend files.

## Publish on Netlify

1. Extract the ZIP file.
2. Create a GitHub account if you do not have one.
3. Create a new GitHub repository named `forever-collection`.
4. Upload all extracted files and folders to that repository.
5. In Netlify, choose **Add new site → Import an existing project**.
6. Connect GitHub and select `forever-collection`.
7. Build command: leave blank. Publish directory: `.`. Functions directory: `netlify/functions`.
8. Deploy. Netlify will give you a temporary `*.netlify.app` URL.

## Enable email notifications

The function uses Resend as the email delivery provider (it does not use your Gmail password).

1. Create an account at https://resend.com/ and verify a sender domain you control.
2. Create an API key.
3. In Netlify: **Site configuration → Environment variables**, add:
   - `RESEND_API_KEY` = your Resend API key
   - `OWNER_EMAIL` = `4evercollectionz@gmail.com`
   - `EMAIL_FROM` = a verified sender, e.g. `Forever Collection <orders@your-verified-domain>`
4. Redeploy the site.

Resend may require domain verification before sending to arbitrary customer addresses. Do not use the example `orders@resend.dev` as a production sender.

## Enable WhatsApp order messages

1. Set up Meta WhatsApp Business Platform / Cloud API at https://developers.facebook.com/docs/whatsapp/cloud-api/.
2. Use a business phone number configured for the Cloud API. Your existing personal number is not automatically an API sender; check Meta's current number migration/coexistence options before changing your number.
3. Create and get approval for a WhatsApp message template. The function expects a template with two body parameters: order reference and order total.
4. Add these Netlify environment variables:
   - `WHATSAPP_ACCESS_TOKEN`
   - `WHATSAPP_PHONE_NUMBER_ID`
   - `WHATSAPP_TEMPLATE_NAME`
   - Optional: `WHATSAPP_API_VERSION` (defaults to `v21.0`)
   - Optional: `WHATSAPP_TEMPLATE_LANGUAGE` (defaults to `en`)
5. Redeploy. Collect customer consent before sending WhatsApp notifications.

## Payment and customer accounts

For a real store, connect:
- Supabase Auth + database for customer accounts, product inventory and persistent orders.
- Razorpay Checkout for UPI/cards and a Netlify Function to create orders and verify Razorpay signatures on the server.
- A persistent database and admin authentication before adding an order-management dashboard.

The current starter does not store orders in a database, authenticate users, charge payments, calculate shipping, or manage inventory. Do not advertise those functions as active until implemented and tested.

## Owner contact shown on the site

WhatsApp contact link: `https://wa.me/917010485038`  
Email: `4evercollectionz@gmail.com`
