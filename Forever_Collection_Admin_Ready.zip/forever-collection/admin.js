const SUPABASE_URL = "https://sgqpbadtkdwoxbeyyiyx.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_QNG8oud12KF4n5Y6nuLXpg_tGHTxSIa";
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
const ADMIN_EMAIL = "esakkichandru2005@gmail.com";
const $ = id => document.getElementById(id);
const say = (id,msg) => $(id).textContent=msg;
const money = n => "₹"+Number(n).toLocaleString("en-IN");
function showDashboard(user){
  if(!user || user.email?.toLowerCase()!==ADMIN_EMAIL){sb.auth.signOut();$('loginPanel').classList.remove('hidden');$('dashboard').classList.add('hidden');say('loginMessage','This account is not authorised for shop administration.');return}
  $('loginPanel').classList.add('hidden');$('dashboard').classList.remove('hidden');loadProducts();
}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();say('loginMessage','Signing in…');const {data,error}=await sb.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});if(error){say('loginMessage',error.message);return}showDashboard(data.user)});
$('logout').onclick=async()=>{await sb.auth.signOut();$('dashboard').classList.add('hidden');$('loginPanel').classList.remove('hidden');$('loginForm').reset();};
$('refresh').onclick=loadProducts;
$('cancelEdit').onclick=clearForm;
function clearForm(){$('productForm').reset();$('productId').value='';$('saveProduct').textContent='Save product';say('productMessage','')}
async function loadProducts(){
  $('productList').innerHTML='<p class="admin-empty">Loading products…</p>';
  const {data,error}=await sb.from('products').select('*').order('created_at',{ascending:false});
  if(error){$('productList').innerHTML='<p class="admin-empty">Could not load products: '+error.message+'</p>';return}
  if(!data.length){$('productList').innerHTML='<p class="admin-empty">No products yet. Add your first product above.</p>';return}
  $('productList').innerHTML=data.map(p=>`<article class="admin-product"><div>${p.image_url?`<img src="${p.image_url}" alt="">`:'<div class="admin-placeholder">✿</div>'}</div><div><strong>${esc(p.name)}</strong><small>${esc(p.category||'Accessories')} · ${money(p.price)} · ${p.is_available?'Available':'Hidden'}</small></div><div class="admin-actions"><button data-edit="${p.id}">Edit</button><button class="delete" data-delete="${p.id}">Delete</button></div></article>`).join('');
  $('productList').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>editProduct(data.find(p=>p.id===b.dataset.edit)));
  $('productList').querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteProduct(b.dataset.delete));
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function editProduct(p){$('productId').value=p.id;$('name').value=p.name;$('category').value=p.category||'Accessories';$('price').value=p.price;$('description').value=p.description||'';$('tag').value=p.tag||'';$('image').value='';$('saveProduct').textContent='Update product';say('productMessage','Editing '+p.name);window.scrollTo({top:0,behavior:'smooth'})}
async function deleteProduct(id){if(!confirm('Delete this product?'))return;const {error}=await sb.from('products').delete().eq('id',id);if(error){alert(error.message);return}loadProducts()}
$('productForm').addEventListener('submit',async e=>{
 e.preventDefault();say('productMessage','Saving product…');$('saveProduct').disabled=true;
 try{const id=$('productId').value;const file=$('image').files[0];let image_url;
  if(file){if(file.size>5*1024*1024)throw new Error('Please choose an image smaller than 5 MB.');if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Use JPG, PNG or WEBP images.');const ext=file.name.split('.').pop().toLowerCase();const path=crypto.randomUUID()+'.'+ext;const {error:upErr}=await sb.storage.from('product-images').upload(path,file,{upsert:false,contentType:file.type});if(upErr)throw upErr;image_url=sb.storage.from('product-images').getPublicUrl(path).data.publicUrl;}
  const payload={name:$('name').value.trim(),category:$('category').value,price:Number($('price').value),description:$('description').value.trim(),tag:$('tag').value.trim(),is_available:true};if(image_url)payload.image_url=image_url;
  const result=id?await sb.from('products').update(payload).eq('id',id):await sb.from('products').insert(payload);if(result.error)throw result.error;
  say('productMessage',id?'Product updated successfully.':'Product added successfully.');clearForm();loadProducts();
 }catch(err){say('productMessage',err.message||'Something went wrong.')}finally{$('saveProduct').disabled=false}
});
sb.auth.getSession().then(({data})=>showDashboard(data.session?.user||null));
sb.auth.onAuthStateChange((_event,session)=>{if(session?.user)showDashboard(session.user)});
