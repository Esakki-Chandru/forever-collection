// Netlify Function: receives checkout requests and sends email notifications.
// Configure the environment variables listed in README.md before taking real orders.
const crypto = require("crypto");

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: corsHeaders(), body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: corsHeaders(), body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const order = JSON.parse(event.body || "{}");
    const c = order.customer || {};
    if (!c.name || !c.email || !c.phone || !c.address || !c.pincode || !Array.isArray(order.items) || !order.items.length) {
      return { statusCode: 400, headers: corsHeaders(), body: JSON.stringify({ error: "Missing required order details" }) };
    }
    if (!process.env.RESEND_API_KEY || !process.env.OWNER_EMAIL) {
      return { statusCode: 503, headers: corsHeaders(), body: JSON.stringify({ error: "Order notifications are not configured" }) };
    }

    const orderId = "FC-" + Date.now().toString(36).toUpperCase() + "-" + crypto.randomBytes(2).toString("hex").toUpperCase();
    const rows = order.items.map(i => `<tr><td>${escapeHtml(i.name)}</td><td>${Number(i.quantity)}</td><td>₹${Number(i.price)}</td><td>₹${Number(i.price) * Number(i.quantity)}</td></tr>`).join("");
    const address = `${escapeHtml(c.address)}, ${escapeHtml(c.pincode)}`;
    const common = `<p><b>Order:</b> ${orderId}</p><table border="1" cellpadding="8" cellspacing="0"><tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>${rows}</table><p><b>Total:</b> ₹${Number(order.total)}</p><p><b>Payment:</b> ${escapeHtml(order.paymentMethod || "Not specified")}</p><p><b>Shipping:</b> ${address}</p>`;
    await sendEmail(c.email, `Your Forever Collection order ${orderId}`, `<p>Hi ${escapeHtml(c.name)},</p><p>Thank you for shopping with Forever Collection. We have received your order request.</p>${common}<p>We will contact you with updates.</p>`);
    await sendEmail(process.env.OWNER_EMAIL, `New Forever Collection order ${orderId}`, `<p>A new order has been placed.</p><p><b>Customer:</b> ${escapeHtml(c.name)}<br><b>Email:</b> ${escapeHtml(c.email)}<br><b>Phone:</b> ${escapeHtml(c.phone)}</p>${common}`);

    // WhatsApp Cloud API sends only if a business phone number, token and approved template are configured.
    if (process.env.WHATSAPP_ACCESS_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_TEMPLATE_NAME) {
      await sendWhatsApp(c.phone, orderId, Number(order.total));
    }

    return { statusCode: 200, headers: corsHeaders(), body: JSON.stringify({ orderId, message: "Order notifications sent" }) };
  } catch (error) {
    console.error("create-order error", error);
    return { statusCode: 500, headers: corsHeaders(), body: JSON.stringify({ error: "Could not process order" }) };
  }
};

async function sendEmail(to, subject, html) {
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: process.env.EMAIL_FROM || "Forever Collection <orders@resend.dev>", to: [to], subject, html })
  });
  if (!response.ok) throw new Error("Email provider rejected request: " + await response.text());
}
async function sendWhatsApp(rawPhone, orderId, total) {
  const phone = String(rawPhone).replace(/\D/g, "");
  const version = process.env.WHATSAPP_API_VERSION || "v21.0";
  const url = `https://graph.facebook.com/${version}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;
  const response = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp", to: phone, type: "template",
      template: { name: process.env.WHATSAPP_TEMPLATE_NAME, language: { code: process.env.WHATSAPP_TEMPLATE_LANGUAGE || "en" },
        components: [{ type: "body", parameters: [{ type: "text", text: orderId }, { type: "text", text: `₹${total}` }] }]
      }
    })
  });
  if (!response.ok) throw new Error("WhatsApp provider rejected request: " + await response.text());
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}
function corsHeaders() {
  return { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
}