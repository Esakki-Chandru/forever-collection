const SUPABASE_URL = "https://sgqpbadtkdwoxbeyyiyx.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_QNG8oud12KF4n5Y6nuLXpg_tGHTxSIa";
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
let products = [];
let cart = JSON.parse(localStorage.getItem("fc-cart") || "[]");
let activeCategory = "All";
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const byId = id => products.find(p => p.id === id);
const grid = document.getElementById("productGrid");
const drawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const dialog = document.getElementById("checkoutDialog");
const safe = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "'":"&#39;"}[c]));
function renderProducts(){
  const visible = activeCategory === "All" ? products : products.filter(p=>p.category===activeCategory);
  grid.innerHTML = visible.length ? visible.map(p=>`<article class="product-card"><div class="product-art" style="background:${safe(p.bg_color || '#fff0f6')}">${p.tag?`<span class="tag">${safe(p.tag)}</span>`:''}${p.image_url?`<img class="product-photo" src="${safe(p.image_url)}" alt="${safe(p.name)}" loading="lazy">`:`<span class="emoji">${safe(p.emoji || '✿')}</span>`}</div><div class="product-info"><h3>${safe(p.name)}</h3><p>${safe(p.description || '')}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${p.id}">＋ Add</button></div></div></article>`).join("") : '<p class="shop-empty">New favourites are coming soon. Please check back! ♡</p>';
}
function saveCart(){localStorage.setItem("fc-cart",JSON.stringify(cart));renderCart()}
function add(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();toast("Added to your bag ♡")}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart()}
function total(){return cart.reduce((s,x)=>s+(byId(x.id)?.price||0)*x.qty,0)}
function renderCart(){
  cart=cart.filter(x=>byId(x.id));
  const count=cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("subtotal").textContent=money(total());
  document.getElementById("checkoutTotal").textContent=money(total());
  document.getElementById("checkoutButton").disabled=!cart.length;
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>{const p=byId(x.id);return `<div class="cart-line"><div class="cart-thumb" style="background:${safe(p.bg_color || '#fff0f6')}">${p.image_url?`<img src="${safe(p.image_url)}" alt="">`:safe(p.emoji||'✿')}</div><div><b>${safe(p.name)}</b><small>${money(p.price)} each</small><div class="qty"><button data-qty="${p.id}" data-delta="-1">−</button><span>${x.qty}</span><button data-qty="${p.id}" data-delta="1">＋</button></div></div><b>${money(p.price*x.qty)}</b></div>`}).join(""):'<div class="empty-cart">Your bag is waiting for something lovely ♡</div>';
  localStorage.setItem("fc-cart",JSON.stringify(cart));
}
function openCart(){drawer.classList.add("show");overlay.classList.add("show")}
function closeCart(){drawer.classList.remove("show");overlay.classList.remove("show")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
document.getElementById("filters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;activeCategory=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
grid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)add(b.dataset.add)});
document.getElementById("cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(b)changeQty(b.dataset.qty,Number(b.dataset.delta))});
document.getElementById("openCart").onclick=openCart;document.getElementById("closeCart").onclick=closeCart;overlay.onclick=closeCart;
document.getElementById("checkoutButton").onclick=()=>{closeCart();document.getElementById("formMessage").textContent="";dialog.showModal()};
document.getElementById("closeCheckout").onclick=()=>dialog.close();
document.getElementById("checkoutForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!cart.length)return;
  const form=new FormData(e.currentTarget);
  const order={customer:{name:form.get("name"),email:form.get("email"),phone:form.get("phone"),pincode:form.get("pincode"),address:form.get("address")},paymentMethod:form.get("payment"),items:cart.map(x=>({id:x.id,name:byId(x.id)?.name,price:byId(x.id)?.price,quantity:x.qty})),total:total(),createdAt:new Date().toISOString()};
  const button=document.getElementById("placeOrder");button.disabled=true;button.textContent="Submitting…";
  try{const response=await fetch("/.netlify/functions/create-order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(order)});if(!response.ok)throw new Error();const result=await response.json();document.getElementById("formMessage").textContent=`Thank you! Your order reference is ${result.orderId}. We have received your order request.`;cart=[];saveCart();e.currentTarget.reset();button.textContent="Order received";setTimeout(()=>{dialog.close();button.disabled=false;button.textContent="Place order"},2800)}catch(err){document.getElementById("formMessage").textContent="Order submission is not connected yet. Please contact us on WhatsApp to complete your order.";button.disabled=false;button.textContent="Place order"}
});
async function loadProducts(){
  grid.innerHTML='<p class="shop-empty">Loading the collection…</p>';
  const {data,error}=await supabaseClient.from('products').select('*').eq('is_available',true).order('created_at',{ascending:false});
  if(error){grid.innerHTML='<p class="shop-empty">We could not load products just now. Please refresh the page.</p>';console.error(error);return}
  products=data||[];renderProducts();renderCart();
}
renderCart();loadProducts();
