-- Forever Collection product fields
alter table public.products add column if not exists category text not null default 'Accessories';
alter table public.products add column if not exists tag text;
alter table public.products add column if not exists bg_color text default '#fff0f6';
alter table public.products add column if not exists emoji text default '✿';

-- Public can read available products; only the shop admin can manage them.
alter table public.products enable row level security;
drop policy if exists "Anyone can view products" on public.products;
drop policy if exists "Admin insert products" on public.products;
drop policy if exists "Admin update products" on public.products;
drop policy if exists "Admin delete products" on public.products;
create policy "Anyone can view available products" on public.products for select to anon, authenticated using (is_available = true);
create policy "Forever admin insert products" on public.products for insert to authenticated with check ((select auth.jwt() ->> 'email') = 'esakkichandru2005@gmail.com');
create policy "Forever admin update products" on public.products for update to authenticated using ((select auth.jwt() ->> 'email') = 'esakkichandru2005@gmail.com') with check ((select auth.jwt() ->> 'email') = 'esakkichandru2005@gmail.com');
create policy "Forever admin delete products" on public.products for delete to authenticated using ((select auth.jwt() ->> 'email') = 'esakkichandru2005@gmail.com');

-- Public image viewing is enabled by making product-images a public bucket.
-- Only the admin email can upload, update or delete objects in that bucket.
drop policy if exists "Forever admin upload" on storage.objects;
drop policy if exists "Forever admin update" on storage.objects;
drop policy if exists "Forever admin delete" on storage.objects;
create policy "Forever admin upload" on storage.objects for insert to authenticated with check (bucket_id='product-images' and (select auth.jwt() ->> 'email')='esakkichandru2005@gmail.com');
create policy "Forever admin update" on storage.objects for update to authenticated using (bucket_id='product-images' and (select auth.jwt() ->> 'email')='esakkichandru2005@gmail.com') with check (bucket_id='product-images' and (select auth.jwt() ->> 'email')='esakkichandru2005@gmail.com');
create policy "Forever admin delete" on storage.objects for delete to authenticated using (bucket_id='product-images' and (select auth.jwt() ->> 'email')='esakkichandru2005@gmail.com');
