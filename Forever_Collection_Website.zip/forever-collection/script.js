const products = [
  {id:"fc01",name:"Pastel Bloom Claw Clip",category:"Claw clips",price:49,emoji:"🌸",bg:"#ffe1ec",tag:"BESTSELLER",desc:"A pretty pop of pastel"},
  {id:"fc02",name:"Everyday Mini Clips",category:"Mini clips",price:20,emoji:"🎀",bg:"#ffe9b7",tag:"CUTE PICK",desc:"Tiny clips, endless styling"},
  {id:"fc03",name:"Lavender Twist Clip",category:"Claw clips",price:59,emoji:"💜",bg:"#e7ddff",tag:"NEW",desc:"A soft touch of colour"},
  {id:"fc04",name:"Sweetheart Hair Pins",category:"Accessories",price:35,emoji:"💗",bg:"#ffd9d6",tag:"LOVELY",desc:"Little details for your look"},
  {id:"fc05",name:"Buttercup Mini Set",category:"Mini clips",price:30,emoji:"🌼",bg:"#fff0a9",tag:"VALUE SET",desc:"A sunny little set"},
  {id:"fc06",name:"Pearl Shine Clip",category:"Accessories",price:69,emoji:"🤍",bg:"#e6f0ed",tag:"ELEGANT",desc:"Simple, sweet and timeless"},
  {id:"fc07",name:"Berry Pop Claw Clip",category:"Claw clips",price:55,emoji:"🍓",bg:"#ffd6d7",tag:"FUN FAVOURITE",desc:"A playful everyday accessory"},
  {id:"fc08",name:"Rainbow Mini Set",category:"Mini clips",price:40,emoji:"🌈",bg:"#e4e1ff",tag:"COLOUR POP",desc:"A little colour for every day"}
];
let cart = JSON.parse(localStorage.getItem("fc-cart") || "[]");
let activeCategory = "All";
const money = n => "₹" + n.toLocaleString("en-IN");
const byId = id => products.find(p => p.id === id);
const grid = document.getElementById("productGrid");
const drawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const dialog = document.getElementById("checkoutDialog");
function renderProducts(){
  const visible = activeCategory === "All" ? products : products.filter(p=>p.category===activeCategory);
  grid.innerHTML = visible.map(p=>`<article class="product-card"><div class="product-art" style="background:${p.bg}"><span class="tag">${p.tag}</span><span class="emoji">${p.emoji}</span></div><div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${p.id}">＋ Add</button></div></div></article>`).join("");
}
function saveCart(){localStorage.setItem("fc-cart",JSON.stringify(cart));renderCart()}
function add(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();toast("Added to your bag ♡")}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart()}
function total(){return cart.reduce((s,x)=>s+byId(x.id).price*x.qty,0)}
function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("subtotal").textContent=money(total());
  document.getElementById("checkoutTotal").textContent=money(total());
  document.getElementById("checkoutButton").disabled=!cart.length;
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>{const p=byId(x.id);return `<div class="cart-line"><div class="cart-thumb" style="background:${p.bg}">${p.emoji}</div><div><b>${p.name}</b><small>${money(p.price)} each</small><div class="qty"><button data-qty="${p.id}" data-delta="-1">−</button><span>${x.qty}</span><button data-qty="${p.id}" data-delta="1">＋</button></div></div><b>${money(p.price*x.qty)}</b></div>`}).join(""):'<div class="empty-cart">Your bag is waiting for something lovely ♡</div>';
}
function openCart(){drawer.classList.add("show");overlay.classList.add("show")}
function closeCart(){drawer.classList.remove("show");overlay.classList.remove("show")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
document.getElementById("filters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;activeCategory=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
grid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)add(b.dataset.add)});
document.getElementById("cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(b)changeQty(b.dataset.qty,Number(b.dataset.delta))});
document.getElementById("openCart").onclick=openCart;document.getElementById("closeCart").onclick=closeCart;overlay.onclick=closeCart;
document.getElementById("checkoutButton").onclick=()=>{closeCart();document.getElementById("formMessage").textContent="";dialog.showModal()};
document.getElementById("closeCheckout").onclick=()=>dialog.close();
document.getElementById("checkoutForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!cart.length)return;
  const form=new FormData(e.currentTarget);
  const order={customer:{name:form.get("name"),email:form.get("email"),phone:form.get("phone"),pincode:form.get("pincode"),address:form.get("address")},paymentMethod:form.get("payment"),items:cart.map(x=>({id:x.id,name:byId(x.id).name,price:byId(x.id).price,quantity:x.qty})),total:total(),createdAt:new Date().toISOString()};
  const button=document.getElementById("placeOrder");button.disabled=true;button.textContent="Submitting…";
  try{
    const response=await fetch("/.netlify/functions/create-order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(order)});
    if(!response.ok)throw new Error("Order service is not configured yet.");
    const result=await response.json();
    document.getElementById("formMessage").textContent=`Thank you! Your order reference is ${result.orderId}. We have received your order request.`;
    cart=[];saveCart();e.currentTarget.reset();button.textContent="Order received";
    setTimeout(()=>{dialog.close();button.disabled=false;button.textContent="Place order"},2800);
  }catch(err){
    // Local preview fallback: do not pretend an order was transmitted.
    document.getElementById("formMessage").textContent="The shop preview is working, but order submission is not connected yet. Publish with the Netlify function and notification settings configured before accepting real orders.";
    button.disabled=false;button.textContent="Place order";
  }
});
renderProducts();renderCart();